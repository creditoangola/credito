// SEO por página: título, descrição e palavras-chave. Usado pelas páginas e por scripts/seo-check.mjs.
// primary: palavra principal (densidade alvo ~2,5%). secondary: expressões de apoio. contextual: termos do tema.
// Nota: "credito" (sem acento) aparece nos URLs, nos nomes de ficheiro e no domínio. O Google e o Bing tratam
// credito = crédito, por isso no texto usamos sempre a ortografia correta.

export interface PageSeo {
  title: string;
  description: string;
  primary: string[];
  secondary: string[];
  contextual: string[];
  /** false = página legal ou sem objetivo de ranking: o verificador não mede a densidade */
  density?: boolean;
}

const PRIMARY = ['crédito', 'credito'];

export const SEO: Record<string, PageSeo> = {
  '/': {
    title: 'Crédito em Angola: simule e peça o seu crédito online',
    description:
      'Simule o seu crédito em kwanzas, veja o total a pagar, os documentos e o prazo. Peça crédito online e nós levamos o pedido aos bancos.',
    primary: PRIMARY,
    secondary: ['pedir crédito', 'simular crédito', 'crédito online'],
    contextual: ['kwanzas', 'taeg', 'prestação', 'documentos', 'banco', 'angola'],
  },
  '/credito-pessoal': {
    title: 'Crédito pessoal em Angola: simule e peça online',
    description:
      'Crédito pessoal em kwanzas: veja a prestação, os documentos que o banco pede e o prazo. Simule grátis e peça o seu crédito em poucos minutos.',
    primary: PRIMARY,
    secondary: ['crédito pessoal', 'pedir crédito pessoal', 'simular crédito pessoal'],
    contextual: ['prestação', 'taeg', 'documentos', 'recibos de salário', 'banco', 'kwanzas'],
  },
  '/credito-automovel': {
    title: 'Crédito automóvel em Angola: simule a prestação',
    description:
      'Crédito automóvel em kwanzas: veja a prestação do carro, os documentos e o prazo. Simule grátis e peça o seu crédito antes de ir ao stand.',
    primary: PRIMARY,
    secondary: ['crédito automóvel', 'pedir crédito automóvel', 'financiar um carro'],
    contextual: ['prestação', 'entrada', 'fatura proforma', 'seguro automóvel', 'banco', 'kwanzas'],
  },
  '/credito-habitacao': {
    title: 'Crédito habitação em Angola: simule a prestação',
    description:
      'Crédito habitação em kwanzas: veja a prestação, os documentos do imóvel e o prazo. Simule grátis e peça o seu crédito para a casa própria.',
    primary: PRIMARY,
    secondary: ['crédito habitação', 'pedir crédito habitação', 'comprar casa'],
    contextual: ['prestação', 'imóvel', 'avaliação', 'registo predial', 'banco', 'kwanzas'],
  },
  '/simulador': {
    title: 'Simulador de crédito em kwanzas: prestação e TAEG',
    description:
      'Simule o seu crédito em kwanzas: veja a prestação mensal, o total a pagar e a TAEG estimada. Grátis e sem compromisso.',
    primary: PRIMARY,
    secondary: ['simular crédito', 'simulador de crédito', 'pedir crédito'],
    contextual: ['prestação', 'taeg', 'taxa de juro', 'prazo', 'kwanzas', 'total a pagar'],
  },
  '/pedir-credito': {
    title: 'Pedir crédito online em Angola: pedido em 3 minutos',
    description:
      'Peça o seu crédito em 5 passos simples: diga quanto precisa e quando, e nós levamos o pedido ao banco. Sem compromisso.',
    primary: PRIMARY,
    secondary: ['pedir crédito', 'pedir crédito online', 'pedido de crédito'],
    contextual: ['passo', 'banco', 'documentos', 'whatsapp', 'prestação', 'kwanzas'],
  },
  '/bancos': {
    title: 'Bancos em Angola: documentos e requisitos de crédito',
    description:
      'Compare o crédito dos bancos em Angola: documentos, requisitos e taxas com ligação à fonte oficial e data de atualização.',
    primary: PRIMARY,
    secondary: ['crédito pessoal', 'pedir crédito', 'bancos em angola'],
    contextual: ['taxa de juro', 'taeg', 'documentos', 'requisitos', 'ficha técnica', 'kwanzas'],
  },
  '/blog': {
    title: 'Blog de crédito em Angola: guias para pedir crédito',
    description:
      'Guias simples sobre crédito em Angola: documentos, custos, TAEG e como pedir crédito pessoal, automóvel e habitação.',
    primary: PRIMARY,
    secondary: ['pedir crédito', 'crédito pessoal', 'crédito habitação'],
    contextual: ['guia', 'taeg', 'documentos', 'prestação', 'banco', 'angola'],
  },
  '/aviso-legal': { title: 'Aviso legal e quem somos | Crédito.ao', description: 'Quem somos, o que fazemos e o que não fazemos. Informação legal do Crédito.ao.', primary: PRIMARY, secondary: [], contextual: [], density: false },
  '/privacidade': { title: 'Política de privacidade | Crédito.ao', description: 'Que dados pedimos, para que os usamos e como pode exercer os seus direitos.', primary: PRIMARY, secondary: [], contextual: [], density: false },
  '/termos': { title: 'Termos de utilização | Crédito.ao', description: 'Condições de utilização do site Crédito.ao: o que oferecemos, o que não fazemos e as suas responsabilidades.', primary: PRIMARY, secondary: [], contextual: [], density: false },
};

export const BLOG_KEYWORDS: Record<string, { secondary: string[]; contextual: string[] }> = {
  pessoal: { secondary: ['crédito pessoal', 'pedir crédito'], contextual: ['prestação', 'banco', 'documentos', 'kwanzas'] },
  automovel: { secondary: ['crédito automóvel', 'pedir crédito'], contextual: ['carro', 'entrada', 'banco', 'kwanzas'] },
  habitacao: { secondary: ['crédito habitação', 'pedir crédito'], contextual: ['casa', 'imóvel', 'banco', 'kwanzas'] },
  geral: { secondary: ['pedir crédito', 'crédito pessoal'], contextual: ['taeg', 'banco', 'prestação', 'kwanzas'] },
};
